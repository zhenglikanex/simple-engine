#ifndef COMPONENT_FACTORY_H_
#define COMPONENT_FACTORY_H_

#include <unordered_map>
#include <functional>

#include "Singleton.h"
#include "TypeID.h"

namespace aurora
{
	typedef TypeID ComponentID;

	/*
	 * �������,���ڴ������;
	 */
	template <class Key, class Base>
	class ComponentFactory : public Singleton< ComponentFactory<Key,Base> >
	{
	public:
		/*
		* ������������ٺ���;
		*/
		using ComponentCreationMethod = std::function<Base()>;
		using ComponentDestructionMethod = std::function<bool(Base)>;

		struct ComponentTypeInfo
		{
			ComponentCreationMethod		creation_method_;
			ComponentDestructionMethod	destruction_method_;
		};

		/*
		 * ���ע��,�����������ע���ʹ��;
		 */
		template<class T>
		void RegisterComponent()
		{
			T object;
			Key key(object);

			if (HasComponent(key)) {
				return;
			}

			ComponentTypeInfo info;
			info.creation_method_ = T::create;
			info.destruction_method_ = T::destruct;

			component_type_info_map_[key] = info;
		}

		/*
		 * ɾ�����;
		 */
		template<class T>
		void RemoveComponent()
		{
			T object;
			Key key(object);

			if (HasComponent(key)) {
				component_type_info_map_.erase(key);
			}
		}

		void RemoveComponent(key key)
		{
			if (HasComponent(key)) {
				component_type_info_map_.erase(key);
			}
		}

		/*
		 * �������;
		 */
		template<class T>
		Base* CreateComponent()
		{
			T object;
			Key key(object);

			if (HasComponent(key)) {
				return component_type_info_map_[key].creation_method_();
			}

			return NULL;
		}

		/*
		 * �������;
		 */
		Base CreateCOmponet(Key key)
		{
			if (HasComponent(key)) {
				return component_type_info_map_[key].creation_method_();
			}

			return NULL
		}

		/*
		 * �ͷž���������
		 */
		template<class T>
		void DestoryComponent(Base cmp)
		{
			T object;
			Key key(object);
			if (HasComponent(key)) {
				return component_type_info_map_[key].destruction_method_(cmp);
			}
		}

		void DestoryComponent(Key key, Base cmp)
		{
			if (HasComponent) {
				return component_type_info_map_[key].destruction_method_(cmp);
			}
		}

	private:
		bool HasComponent(const T& key)
		{
			if (component_type_info_map_.find(key) != component_type_info_map_.end()) {
				return true;
			}

			return false;
		}

		//�����Ϣmap;
		std::unordered_map<Key, ComponentTypeInfo> component_type_info_map_;
	};
}

#endif