#ifndef TYPE_ID_H_
#define TYPE_ID_H_


#include <string>
#include <typeinfo>

namespace aurora
{
	/*
	*�������Ͷ���;
	*/
	class TypeID
	{
	public:
		template<class Type>
		TypeID(Type type)
		{
			type_name_ = typeid(Type).name();
		}

		friend bool operator==(const TypeID& ltype, const TypeID& rtype);

		bool operator<(const TypeID& type)
		{
			if (type_name_ < type.type_name_) {
				return true;
			}
			else {
				return false;
			}
		}

	private:
		std::string type_name_;
	};

	bool operator==(const TypeID& ltype, const TypeID& rtype)
	{
		if (ltype.type_name_ == rtype.type_name_) {
			return true;
		}
		else {
			return false;
		}
	}

	inline bool operator!=(const TypeID& ltype, const TypeID& rtype)
	{
		return !(ltype == rtype);
	}
}

#endif