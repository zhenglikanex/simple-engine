#include "IComponent.h"
#include "GameObject.h"

namespace aurora
{
	IComponent::IComponent()
		:gameObject_(0)
	{

	}

	IComponent::~IComponent()
	{
	}

	GameObject* IComponent::getGameObject()
	{
		return gameObject_;
	}
}

