#include "GameObject.h"
#include "IComponent.h"

namespace aurora
{
	GameObject::GameObject()
	{
	}

	GameObject::~GameObject()
	{
	}

	IComponentPtr GameObject::GetComponent(ComponentID id)
	{
		auto iter = component_map_.find(id);
		if (iter == component_map_.end()) {
			return NULL;
		}

		return iter->second;
	}
}